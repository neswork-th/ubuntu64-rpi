"""
The monitor extracts data about the local machine and sends it in
messages to the Landcsape server via the broker.
"""
