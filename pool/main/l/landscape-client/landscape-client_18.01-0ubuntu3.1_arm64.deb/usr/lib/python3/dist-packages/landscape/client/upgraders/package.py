from landscape.client.patch import SQLiteUpgradeManager

upgrade_manager = SQLiteUpgradeManager()
