/* This file is auto generated, version 31-Ubuntu */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#31-Ubuntu SMP Tue Jul 17 15:41:03 UTC 2018"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "bos02-arm64-004"
#define LINUX_COMPILER "gcc version 7.3.0 (Ubuntu/Linaro 7.3.0-16ubuntu3)"
