#!/usr/bin/python3

from DistUpgrade.DistUpgradeMain import main
import sys


if __name__ == "__main__":
    sys.exit(main())
