Common Job Definition Categories
================================

This provider ships definitions of common test definition categories.
Categories defined in this provider can be used by any other provider.