Hardware Manifest Provider
==========================

This provider ships a standard resource job for accessing the hardware manifest
as well as a standard interactive job for collecting the manifest data from the
test operator.
